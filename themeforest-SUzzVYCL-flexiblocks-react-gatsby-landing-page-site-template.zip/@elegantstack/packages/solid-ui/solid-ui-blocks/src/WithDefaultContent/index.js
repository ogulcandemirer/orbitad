export { default } from './WithDefaultContent'
