export { default } from './WithRecentPosts'
