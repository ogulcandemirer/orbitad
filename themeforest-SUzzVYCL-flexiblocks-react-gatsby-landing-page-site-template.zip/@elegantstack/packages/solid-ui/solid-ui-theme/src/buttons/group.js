export default {
  '> * + a, > * + button, > * + div': {
    ml: 4,
    mt: [3, null, 0]
  }
}
