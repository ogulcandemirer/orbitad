export default {
  outline: 0,
  userSelect: `none`,
  WebkitTapHighlightColor: `transparent`,
  borderRadius: `xl`,
  cursor: `pointer`,
  transition: `all 250ms ease`
}
