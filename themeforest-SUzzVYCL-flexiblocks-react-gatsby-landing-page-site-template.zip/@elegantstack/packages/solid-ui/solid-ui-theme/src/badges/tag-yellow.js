import common from './common'

export default {
  ...common.badge,
  bg: '#FEF9D8',
  color: '#D6AE2E'
}
