export default {
  variant: 'cards.primary',
  borderRadius: `xl`,
  p: [4, 5]
}
