export default {
  color: `alpha`,
  textDecoration: `none`,
  userSelect: `none`,
  cursor: `pointer`,
  whiteSpace: `pre`,
  transition: `all 250ms ease`,
  p: 0,
  ':visited': {
    color: 'alpha'
  },
  ':hover': {
    color: 'alphaDark'
  }
}
