import React from 'react'
import { Input } from 'theme-ui'

const FormHidden = ({ ...props }) => <Input {...props} type='hidden' />
export default FormHidden
